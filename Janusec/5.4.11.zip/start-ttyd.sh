#!/bin/sh -e

while [ ! -f "/usr/local/janusec/certs/ca/ttyd.crt" ]; do
    echo "等待证书文件"
    sleep 5
done

user=$(md5sum /usr/local/janusec/certs/ca/client.crt | cut -d ' ' -f 1)
pass=$(md5sum /usr/local/janusec/certs/ca/client.key | cut -d ' ' -f 1)
port=12346

echo -n "$user:$pass:$port" > /tmp/ttyd.auth

./ttyd -W -S -p $port -c "$user:$pass" -C /usr/local/janusec/certs/ca/ttyd.crt -K /usr/local/janusec/certs/ca/ttyd.key -A /usr/local/janusec/certs/ca/ca.crt /bin/bash

