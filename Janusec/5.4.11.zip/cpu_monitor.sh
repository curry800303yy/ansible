#!/bin/bash


# 运行sar命令并获取最后一行的输出
output=$(sar -u 1 1 | tail -1)

# 从输出中提取%idle值
idle=$(echo $output | awk '{print $NF}')

# 计算CPU使用率
cpu_usage=$(awk "BEGIN {print 100 - $idle}")
echo `date` "cpu: " $cpu_usage  >> /monitor/cpu_monitor.log

# 检查CPU使用率是否超过90%
if (( $(echo "$cpu_usage > 85" | bc -l) )); then
    echo "  cpu: " $cpu_usage "，指标异常">> /monitor/cpu_monitor.log

    # 删除旧的perf记录文件
    rm perf.data.old 2> /dev/null

    # 如果存在，将当前的perf记录文件重命名为旧文件
    if [ -f "/monitor/perf.data" ]; then
        mv /monitor/perf.data /monitor/perf.data.old
    fi

    # 执行perf record命令记录10秒钟
    /usr/bin/perf record -a -g -o /monitor/perf.data -- sleep 10
fi