echo '
* soft nofile 1024000
* hard nofile 1024000
* soft nproc 65535
* hard nproc 65535
' > /etc/security/limits.conf