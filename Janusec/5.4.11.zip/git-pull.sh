#!/bin/bash -ex
git_pull() {
    mkdir -p /usr/local/janusec/.data/config

    if [ ! -d /usr/local/janusec/.data/config/edge/.git ]; then
        gitUrl=`grep sync_addr /usr/local/janusec/config.json | awk -F '"' '{print $4}'`
        chmod 600 /usr/local/janusec/certs/ca/client.key

        git -c core.sshCommand="ssh -o PasswordAuthentication=no -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -i /usr/local/janusec/certs/ca/client.key"\
         clone $gitUrl /usr/local/janusec/.data/config/edge
        cd /usr/local/janusec/.data/config/edge
        git config user.name EdgeNode
        git config user.email "edge@waf.node"
        git config pull.ff only
        git config core.sshCommand "ssh -o PasswordAuthentication=no -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -i /usr/local/janusec/certs/ca/client.key"
    fi

    cd /usr/local/janusec/.data/config/edge
    chmod 600 /usr/local/janusec/certs/ca/client.key
    if ! git fetch origin master; then
        git fetch -f origin master
    fi
    git reset --hard origin/master
    git reflog expire --all
    git gc --prune=now
}

git_pull  # 第一次检查
sleep 30  # 间隔30秒
git_pull  # 第二次检查