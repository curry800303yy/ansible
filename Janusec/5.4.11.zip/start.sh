#!/bin/sh -e

if [ -e install_flag ]; then
    echo "installing ..."
    if systemctl is-active --quiet agent; then
        systemctl stop agent
    fi
    if systemctl is-active --quiet fluent-bit; then
        systemctl stop fluent-bit
    fi
    if systemctl is-active --quiet exporter; then
        systemctl stop exporter
    fi
    if systemctl is-active --quiet ttyd; then
        systemctl stop ttyd
    fi

    # 安装cpu负载监控脚本
    if command -v sar &> /dev/null; then
        echo "sar命令存在"
    else
        echo "sar命令不存在，准备安装"
        apt update
        apt install -y sysstat
    fi
    if command -v perf &> /dev/null; then
        echo "perf命令存在"
    else
        echo "perf命令不存在，准备安装"
        apt update
        apt install -y linux-tools-common linux-tools-generic linux-tools-$(uname -r)
    fi
    monitor_dir="/monitor"
    cpu_monitor_cron_file="/etc/cron.d/cpu_monitor_cron"

    if [ ! -d "$monitor_dir" ]; then
        mkdir $monitor_dir
    fi

    if [ -e $cpu_monitor_cron_file ]; then
        rm -f $cpu_monitor_cron_file
    fi

    chmod +x cpu_monitor.sh
    if [ ! -e /etc/cron.d/cpu_monitor_cron ]; then
        echo "* * * * * root /usr/local/janusec/cpu_monitor.sh" >> $cpu_monitor_cron_file
    fi


    # 检查是否有 fluent-bit，如果没有则安装
    if [ ! -f /opt/fluent-bit/bin/fluent-bit ]; then
        curl -k https://raw.githubusercontent.com/fluent/fluent-bit/master/install.sh | sh
    fi

    chmod +x ./node_exporter ./ttyd ./start-ttyd.sh ./janusec ./limits.sh ./sysctl.sh

    # 设置 git-pull.sh 每分钟执行一次
    ! grep -q git-pull.sh /etc/crontab && echo '*/1 * * * * root /usr/local/janusec/git-pull.sh' | tee -a /etc/crontab > /dev/null

    # 删除janusec_monitor.sh
    rm -f ./janusec_monitor.sh
    sed -i '/janusec_monitor.sh/d' /etc/crontab

    # 应用系统限制和内核参数
    ./limits.sh
    ./sysctl.sh

    cp -f ./fluent-bit.service /etc/systemd/system/
    cp -f ./exporter.service /etc/systemd/system/
    cp -f ./ttyd.service /etc/systemd/system/
    cp -f ./agent.service /etc/systemd/system/

    systemctl daemon-reload

    systemctl start fluent-bit
    systemctl start exporter
    systemctl start ttyd
    systemctl start agent

    systemctl enable fluent-bit
    systemctl enable exporter
    systemctl enable ttyd
    systemctl enable agent

    rm -f install_flag
fi

# 启动 janusec
CONFIG=./config.json
# 如果有传入的配置文件，则使用它
if [ -n "$1" ]; then
    CONFIG="$1"
fi
if [ ! -f $CONFIG ]; then
    echo "错误：未找到配置文件 $CONFIG" >&2
fi
./janusec -config $CONFIG