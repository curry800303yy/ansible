#!/bin/bash

# 检查并加载 tcp_bbr 模块
if ! grep -q "^tcp_bbr" /etc/modules; then
    echo 'tcp_bbr' >> /etc/modules
fi

# 尝试加载 tcp_bbr 模块
if ! lsmod | grep -q bbr; then
    modprobe tcp_bbr
    if [ $? -ne 0 ]; then
        echo "错误: 无法加载 tcp_bbr 模块，请检查内核是否支持" >&2
        exit 1
    fi
    echo "已成功加载 tcp_bbr 模块"
else
    echo "tcp_bbr 模块已加载"
fi

# 备份 sysctl.conf 文件（如果存在），添加时间戳避免覆盖
if [ -f /etc/sysctl.conf ]; then
    timestamp=$(date +%Y%m%d%H%M%S)
    cp /etc/sysctl.conf /etc/sysctl.conf.bk.$timestamp
    echo "已备份原 sysctl.conf 到 sysctl.conf.bk.$timestamp"
fi

# 设置系统参数
cat > /etc/sysctl.conf << EOF
# 启用 SysRq 功能，允许通过键盘组合键向内核发送特殊命令（1 表示启用）
kernel.sysrq = 1

# Memory/VM
# 控制内存交换倾向，值越小越不倾向于使用交换空间（默认 60）
vm.swappiness = 10
# 当脏页占总内存的比例达到此值时，系统会开始同步脏页到磁盘
vm.dirty_ratio = 20
# 当脏页占总内存的比例达到此值时，后台进程开始同步脏页到磁盘
vm.dirty_background_ratio = 10
# 脏页写入磁盘的时间间隔（厘秒），默认 500 厘秒（5 秒）
vm.dirty_writeback_centisecs = 100

# 网络相关设置
# TIME_WAIT 状态套接字的最大数量，超过此值将被立即清除
net.ipv4.tcp_max_tw_buckets = 500000
# 禁用空闲连接后的 TCP 慢启动，保持原有连接速度
net.ipv4.tcp_slow_start_after_idle = 0
# 本地端口动态分配范围，可用于建立连接的端口范围
net.ipv4.ip_local_port_range = 1024 65535
# 网络接收缓冲区的最大大小（字节）
net.core.rmem_max=16777216
# 网络发送缓冲区的最大大小（字节）
net.core.wmem_max=16777216
# 网络接收缓冲区的默认大小（字节）
net.core.rmem_default=4194304
# 网络发送缓冲区的默认大小（字节）
net.core.wmem_default=4194304
# TCP 接收缓冲区的最小值、默认值和最大值（字节）
net.ipv4.tcp_rmem=4096 87380 16777216
# TCP 发送缓冲区的最小值、默认值和最大值（字节）
net.ipv4.tcp_wmem=4096 65536 16777216
# 允许重用处于 TIME_WAIT 状态的套接字
net.ipv4.tcp_tw_reuse = 1
# FIN_WAIT_2 状态的超时时间（秒），缩短连接关闭等待时间
net.ipv4.tcp_fin_timeout = 10
# TCP 保活机制的空闲检测时间（秒），默认 7200 秒（2 小时）
net.ipv4.tcp_keepalive_time = 180
# 注释掉的配置：禁用 TCP 时间戳，可减少某些攻击风险
# net.ipv4.tcp_timestamps = 0
# 网络设备接收队列的最大长度，提高网络突发流量处理能力
net.core.netdev_max_backlog = 500000
# 启用 SYN Cookie 保护，防止 SYN Flood 攻击
net.ipv4.tcp_syncookies = 1
# 注释掉的配置：系统可保留的孤儿套接字最大数量
# net.ipv4.tcp_max_orphans = 262144
# SYN+ACK 包的重传次数，减少建立连接的延迟
net.ipv4.tcp_synack_retries = 2
# SYN 包的重传次数，减少建立连接的延迟
net.ipv4.tcp_syn_retries = 2
# 启用 TCP Fast Open 加速首次连接，3 表示同时支持客户端和服务器端
net.ipv4.tcp_fastopen = 3
# 半连接队列的最大长度，提高高并发下的连接处理能力
net.ipv4.tcp_max_syn_backlog = 65536
# 监听套接字的最大连接请求队列长度
net.core.somaxconn = 65536
# 默认的网络队列调度算法，fq 提供公平排队和更好的带宽利用
net.core.default_qdisc=fq
# TCP 拥塞控制算法，BBR 可提高高带宽、高延迟网络的性能

# Filesystem
# 系统允许的最大文件句柄数量，提高系统可打开的文件数量上限, 2025-10-16 确认先不配置此值
# fs.file-max = 1000000
# 系统允许的最大异步 I/O 请求数量，提高异步 I/O 性能
fs.aio-max-nr = 1048576
EOF

# 应用 sysctl 配置
echo "正在应用 sysctl 配置..."
sysctl -p

# 验证 BBR 是否已启用（移到 sysctl -p 之后）
if sysctl net.ipv4.tcp_congestion_control | grep -q bbr; then
    echo "BBR 拥塞控制已成功启用"
else
    echo "警告: BBR 拥塞控制未启用，请检查内核版本是否支持" >&2
fi

# 修复 fluent-bit 的 gpg KEY 导入问题
# curl -k -L https://packages.fluentbit.io/fluentbit.key | gpg --dearmor > /usr/share/keyrings/fluentbit-keyring.gpg