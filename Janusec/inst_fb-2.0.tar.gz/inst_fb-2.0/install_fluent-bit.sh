#!/bin/sh -e

if [ ! -d "/opt" ]; then
  mkdir /opt
  echo "Created /opt"
fi

if [ ! -d "/opt/fluent-bit" ]; then
  mkdir /opt/fluent-bit
  echo "Created /opt/fluent-bit"
fi


if [ ! -d "/opt/fluent-bit/bin" ]; then
  mkdir /opt/fluent-bit/bin
  echo "Created /opt/fluent-bit/bin"
fi

if [ ! -e "/opt/fluent-bit/bin/fluent-bit" ]; then
  cp ./fluent-bit /opt/fluent-bit/bin/
  chmod +x /opt/fluent-bit/bin/fluent-bit
  echo "Copied fluent-bit"
fi

if [ ! -d "/etc/fluent-bit" ]; then
  mkdir /etc/fluent-bit
  echo "Created /etc/fluent-bit"
fi

if [ ! -e "/etc/fluent-bit/fluent-bit.conf" ]; then
  cp ./parsers.conf /etc/fluent-bit/
  echo "Copied parsers.conf"
fi

if [ ! -e "/etc/fluent-bit/plugins.conf" ]; then
  cp ./plugins.conf /etc/fluent-bit/
  echo "Copied plugins.conf"
fi

if [ -f "/etc/systemd/system/fluent-bit.service" ] || [ -f "/lib/systemd/system/fluent-bit.service" ]; then
  systemctl restart fluent-bit >/dev/null 2>&1
  echo "Restarted fluent-bit.service."
fi
